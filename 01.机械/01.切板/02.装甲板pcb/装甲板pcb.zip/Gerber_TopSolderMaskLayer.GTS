G04 Layer: TopSolderMaskLayer*
G04 EasyEDA Pro v2.1.42.467b0aa0.3861f9, 2026-01-24 01:08:11*
G04 Gerber Generator version 0.3*
G04 Scale: 100 percent, Rotated: No, Reflected: No*
G04 Dimensions in millimeters*
G04 Leading zeros omitted, absolute positions, 3 integers and 5 decimals*
%FSLAX35Y35*%
%MOMM*%
%ADD10C,3.1016*%
G75*


G04 Pad Start*
G54D10*
G01X-600000Y-600000D03*
G01X-9400000Y-600000D03*
G01X-600000Y-9400000D03*
G01X-9400000Y-9400000D03*
G04 Pad End*

M02*
